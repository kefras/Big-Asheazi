// BIG ASHEAZI - Shared JS
const WA_NUMBER = "2349032154273";

function waLink(message){
  const encoded = encodeURIComponent(message);
  return `https://wa.me/${WA_NUMBER}?text=${encoded}`;
}

function setActiveNav(){
  const here = location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('.menu a').forEach(a => {
    if(a.getAttribute('href').endsWith(here)) a.classList.add('active');
  });
}

function toggleMenu(){
  const m = document.querySelector('.menu');
  m.classList.toggle('open');
}

document.addEventListener('click', (e)=>{
  if(e.target.matches('[data-order]')){
    const item = e.target.getAttribute('data-order');
    const msg = `Hello BIG ASHEAZI! I would like to order: ${item}.`;
    window.open(waLink(msg), '_blank');
  }
});

window.addEventListener('DOMContentLoaded', setActiveNav);