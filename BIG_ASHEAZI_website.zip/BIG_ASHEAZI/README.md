# BIG ASHEAZI – Simple Multi‑Page Website

Pages:
- index.html (Home – hero with food background, CTA)
- about.html (About the brand)
- services.html (Menu grid with WhatsApp “Order now” buttons)
- enquiries.html (Form that redirects to WhatsApp)

How to run:
1) Open any of the .html files in your browser (double‑click).
2) To change the hero photo, put an image at `assets/img/hero.jpg` (landscape works best).
3) Edit menu items in `services.html` via the `SERVICES` array.
4) All WhatsApp actions use `+234 903 215 4273`. Change the number in `assets/js/main.js` if needed.